#include "main.h"

/* Search a word in the inverted search database */
int search_database(Hash_t hash[], char *word)
{
    /* Get the hash index of the word */
    int index = get_index(word);

    /* Point to the first main node of the hash index */
    Mlist *mtemp = hash[index].link;

    /* Traverse the main list */
    while (mtemp != NULL)
    {
        /* Check whether the word matches */
        if (strcmp(mtemp->word, word) == 0)
        {
            /* Display word details */
            printf("\n******** WORD FOUND ********\n");
            printf("-----------------------------------------------\n");
            printf("Word       : %s\n", mtemp->word);
            printf("File Count : %d\n", mtemp->file_count);
            printf("-----------------------------------------------\n");
            printf("%-20s %-10s\n", "File Name", "Word Count");
            printf("-----------------------------------------------\n");

            /* Point to the first sub node */
            Slist *stemp = mtemp->sub_link;

            /* Traverse the sub list */
            while (stemp != NULL)
            {
                /* Display file name and word count */
                printf("%-20s %-10d\n",
                       stemp->file_name,
                       stemp->word_count);

                /* Move to the next sub node */
                stemp = stemp->sub_link;
            }

            printf("-----------------------------------------------\n");

            return SUCCESS;
        }

        /* Move to the next main node */
        mtemp = mtemp->main_link;
    }

    /* Word not found */
    printf("\nWord \"%s\" not found in the database.\n", word);

    return FAILURE;
}