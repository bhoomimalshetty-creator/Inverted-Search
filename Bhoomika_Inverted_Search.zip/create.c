#include "main.h"

/*return the hash index based on the first character of the word*/
int get_index(char *word)
{
    if (word[0] >= 'a' && word[0] <= 'z')//lowercase
        return word[0] - 'a';

    if (word[0] >= 'A' && word[0] <= 'Z')//uppercase
        return word[0] - 'A';

    return 26;
}
/*creates the inverted search database */
int create_database(Flist *head, Hash_t hash[])
{
    FILE *fp;
    char word[WORD_SIZE];

    //traverse all input files
    while (head != NULL)
    {
        fp = fopen(head->file_name, "r");//open current file
        if (fp == NULL)//skip if file cannot be open
        {
            head = head->link;
            continue;
        }

        //read each word from the file
        while (fscanf(fp, "%49s", word) == 1)
        {
            int index = get_index(word);

            Mlist *mtemp = hash[index].link;
            Mlist *mprev = NULL;

            //search for the word in main list
            while (mtemp != NULL)
            {
                if (strcmp(mtemp->word, word) == 0)//stop if word found
                    break;

                mprev = mtemp;//move to the main next node
                mtemp = mtemp->main_link;
            }

            /* Word not present */
            if (mtemp == NULL)
            {
                //allocate memory for new main node if word is not present
                Mlist *mnew = malloc(sizeof(Mlist));
                if (mnew == NULL)
                {
                    fclose(fp);
                    return FAILURE;
                }

                strcpy(mnew->word, word);//store the word in the main node
                mnew->file_count = 1;
                mnew->main_link = NULL;
                mnew->sub_link = NULL;

                //allocate memory for the sub node
                Slist *snew = malloc(sizeof(Slist));
                if (snew == NULL)
                {
                    free(mnew);
                    fclose(fp);
                    return FAILURE;
                }

                strcpy(snew->file_name, head->file_name);//store the file name
                snew->word_count = 1;
                snew->sub_link = NULL;

                mnew->sub_link = snew;

                //insert main node into the hash table
                if (hash[index].link == NULL)
                    hash[index].link = mnew;
                else
                    mprev->main_link = mnew;
            }
            else
            {
                Slist *stemp = mtemp->sub_link;
                Slist *sprev = NULL;

                //search for the current file in the sub list
                while (stemp != NULL)
                {
                    //if file exist increment word count
                    if (strcmp(stemp->file_name, head->file_name) == 0)
                    {
                        stemp->word_count++;
                        break;
                    }

                    sprev = stemp;
                    stemp = stemp->sub_link;
                }

                //create new subnode if file is not found
                if (stemp == NULL)
                {
                    Slist *snew = malloc(sizeof(Slist));//memory allocation for subnode
                    if (snew == NULL)
                    {
                        fclose(fp);
                        return FAILURE;
                    }

                    strcpy(snew->file_name, head->file_name);
                    snew->word_count = 1;
                    snew->sub_link = NULL;

                    //insert subnode into sub list
                    if (sprev == NULL)
                        mtemp->sub_link = snew;
                    else
                        sprev->sub_link = snew;

                    mtemp->file_count++;//increment file count
                }
            }
        }

        fclose(fp);//close current file
        head = head->link;
    }

    return SUCCESS;//database created successfully
}