#include "main.h"

/* Check whether file is already updated */
int check_backup_duplicate(Hash_t hash[], char *filename)
{
    int i;

    for (i = 0; i < HASH_SIZE; i++)
    {
        Mlist *mtemp = hash[i].link;

        while (mtemp != NULL)
        {
            Slist *stemp = mtemp->sub_link;

            while (stemp != NULL)
            {
                if (strcmp(stemp->file_name, filename) == 0)
                    return SUCCESS;

                stemp = stemp->sub_link;
            }

            mtemp = mtemp->main_link;
        }
    }

    return FAILURE;
}

/* Update Database */
int update_database(Hash_t hash[], char *filename, Flist *head)
{
    FILE *fp = fopen(filename, "r");

    if (fp == NULL)
    {
        printf("ERROR: Unable to open backup file\n");
        return FAILURE;
    }

    int index, file_count, word_count;
    char word[WORD_SIZE];
    char file_name[FILE_SIZE];

    while (1)
    {
        if (fscanf(fp, "#%d;%[^;];%d;",
                   &index, word, &file_count) != 3)
            break;

        Mlist *mnew = malloc(sizeof(Mlist));
        if (mnew == NULL)
        {
            fclose(fp);
            return FAILURE;
        }

        strcpy(mnew->word, word);
        mnew->file_count = file_count;
        mnew->main_link = NULL;
        mnew->sub_link = NULL;

        Slist *last = NULL;

        int i;
        for (i = 0; i < file_count; i++)
        {
            fscanf(fp, "%[^;];%d;",
                   file_name,
                   &word_count);

            Slist *snew = malloc(sizeof(Slist));
            if (snew == NULL)
            {
                fclose(fp);
                return FAILURE;
            }

            strcpy(snew->file_name, file_name);
            snew->word_count = word_count;
            snew->sub_link = NULL;

            if (mnew->sub_link == NULL)
                mnew->sub_link = snew;
            else
                last->sub_link = snew;

            last = snew;
        }

        fscanf(fp, "#");

        if (hash[index].link == NULL)
        {
            hash[index].link = mnew;
        }
        else
        {
            Mlist *temp = hash[index].link;

            while (temp->main_link != NULL)
                temp = temp->main_link;

            temp->main_link = mnew;
        }
    }

    /* Add newly created files */
    Flist *temp = head;

    while (temp != NULL)
    {
        if (check_backup_duplicate(hash, temp->file_name) == SUCCESS)
        {
            printf("%s updated... \n",
                   temp->file_name);
        }
        else
        {
            printf("%s is a new file... Creating Database\n",
                   temp->file_name);

            create_database(temp, hash);
        }

        temp = temp->link;
    }

    fclose(fp);

    printf("Database updated successfully\n");

    return SUCCESS;
}