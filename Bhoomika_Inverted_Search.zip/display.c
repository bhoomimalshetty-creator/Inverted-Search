#include "main.h"

/* Display the inverted search database */
void display_database(Hash_t hash[])
{
    int i;

    printf("\n*********** DISPLAY DATABASE *************\n");
    printf("--------------------------------------------------------------------------\n");
    printf("%-8s %-15s %-12s %-20s %-10s\n",
           "Index", "Word", "File Count", "File Name", "Word Count");
    printf("--------------------------------------------------------------------------\n");

    /* Traverse all hash table indices */
    for (i = 0; i < HASH_SIZE; i++)
    {
        /* Skip empty entries */
        if (hash[i].link == NULL)
            continue;

        Mlist *mtemp = hash[i].link;

        /* Traverse the main list */
        while (mtemp != NULL)
        {
            Slist *stemp = mtemp->sub_link;

            /* Print first file details */
            if (stemp != NULL)
            {
                printf("%-8d %-15s %-12d %-20s %-10d\n",
                       hash[i].index,
                       mtemp->word,
                       mtemp->file_count,
                       stemp->file_name,
                       stemp->word_count);

                stemp = stemp->sub_link;
            }

            /* Print remaining files */
            while (stemp != NULL)
            {
                printf("%-8s %-15s %-12s %-20s %-10d\n",
                       "", "", "",
                       stemp->file_name,
                       stemp->word_count);

                stemp = stemp->sub_link;
            }

            mtemp = mtemp->main_link;
        }
    }

    printf("--------------------------------------------------------------------------\n");
}