#include "main.h"

/* Save the inverted search database into a file */
int save_database(Hash_t hash[], char *filename)
{
    // Open the file in write mode
    FILE *fp = fopen(filename, "w");

    // Check whether the file is opened successfully
    if (fp == NULL)
    {
        printf("Unable to open file\n");
        return FAILURE;
    }

    int i;

    // Traverse all hash table indices
    for (i = 0; i < HASH_SIZE; i++)
    {
        // Skip empty hash table entries
        if (hash[i].link == NULL)
            continue;

        // Point to the first main node
        Mlist *mtemp = hash[i].link;

        // Traverse the main list
        while (mtemp != NULL)
        {
            // Write the main node information to the file
            fprintf(fp, "#%d;%s;%d;",
                    i,
                    mtemp->word,
                    mtemp->file_count);

            // Point to the first sub node
            Slist *stemp = mtemp->sub_link;

            // Traverse the sub list
            while (stemp != NULL)
            {
                // Write the sub node information to the file
                fprintf(fp, "%s;%d;",
                        stemp->file_name,
                        stemp->word_count);

                // Move to the next sub node
                stemp = stemp->sub_link;
            }

            // Mark the end of the current record
            fprintf(fp, "#\n");

            // Move to the next main node
            mtemp = mtemp->main_link;
        }
    }

    // Close the file
    fclose(fp);

    // Display success message
    printf("Database saved successfully\n");

    // Return success
    return SUCCESS;
}