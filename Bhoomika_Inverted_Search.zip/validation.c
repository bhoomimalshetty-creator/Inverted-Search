#include "main.h"

/* Validate all command line arguments */
int validate_args(int argc, char *argv[], Flist **head)
{
    int i;

    if (argc < 2)
    {
        printf("Error: No input files provided\n");
        return FAILURE;
    }

    for (i = 1; i < argc; i++)
    {
        if (validate_file(argv[i]) == SUCCESS)
        {
            if (check_duplicate(*head, argv[i]) == FAILURE)
            {
                printf("%s : Duplicate file\n", argv[i]);
                continue;
            }

            insert_last(head, argv[i]);
            printf("%s : Valid file\n", argv[i]);
        }
        else
        {
            printf("%s : Invalid file\n", argv[i]);
        }
    }

    if (*head == NULL)
        return FAILURE;

    return SUCCESS;
}

/* Validate a single file */
int validate_file(char *filename)
{
    FILE *fp;

    fp = fopen(filename, "r");

    if (fp == NULL)
        return FAILURE;

    fseek(fp, 0, SEEK_END);

    if (ftell(fp) == 0)
    {
        fclose(fp);
        return FAILURE;
    }

    fclose(fp);
    return SUCCESS;
}

/* Check duplicate file names */
int check_duplicate(Flist *head, char *filename)
{
    while (head)
    {
        if (strcmp(head->file_name, filename) == 0)
            return FAILURE;

        head = head->link;
    }

    return SUCCESS;
}

/* Insert file at the end of the list */
int insert_last(Flist **head, char *filename)
{
    Flist *new = malloc(sizeof(Flist));

    if (new == NULL)
        return FAILURE;

    strcpy(new->file_name, filename);
    new->link = NULL;

    if (*head == NULL)
    {
        *head = new;
        return SUCCESS;
    }

    Flist *temp = *head;

    while (temp->link)
        temp = temp->link;

    temp->link = new;

    return SUCCESS;
}