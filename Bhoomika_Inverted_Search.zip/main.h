#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SUCCESS 0
#define FAILURE -1

#define HASH_SIZE 28
#define WORD_SIZE 50
#define FILE_SIZE 50

/* File List Node */
typedef struct file_node
{
    char file_name[FILE_SIZE];
    struct file_node *link;
} Flist;

/* Sub Node */
typedef struct sub_node
{
    int word_count;
    char file_name[FILE_SIZE];
    struct sub_node *sub_link;
} Slist;

/* Main Node */
typedef struct main_node
{
    int file_count;
    char word[WORD_SIZE];
    Slist *sub_link;
    struct main_node *main_link;
} Mlist;

/* Hash Table */
typedef struct hash
{
    int index;
    Mlist *link;
} Hash_t;

/* Validation Functions */
int validate_args(int argc, char *argv[], Flist **head);
int validate_file(char *filename);
int check_duplicate(Flist *head, char *filename);
int insert_last(Flist **head, char *filename);

/* Create Database */
int create_database(Flist *head, Hash_t hash[]);
int get_index(char *word);
void display_database(Hash_t hash[]);
int search_database(Hash_t hash[], char *word);

int save_database(Hash_t hash[], char *filename);
extern int db_created;
extern int db_updated;

int update_database(Hash_t hash[], char *filename, Flist *head);
int check_backup_duplicate(Hash_t hash[], char *filename);

#endif