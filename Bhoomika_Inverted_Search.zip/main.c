/*Name - Bhoomika
Date - 04/07/26
Batch - 26001B
Description - Developed an inverted search project in DS using hash tables and Linked lists for efficient word indexing.
The system reads multiple text files, extract words, and stores each word with the corresponding file names and occurance
counts. Implemented Features such as database creation, display, search, save, update for fast and accurate retrival.
Used dynamic memory allocation, file handling, and collision handling techniques optimize search performance. */

#include "main.h"

/* Flag to check whether the database is created */
int db_created = 0;

/* Function prototype */
int check_backup_duplicate(Hash_t hash[], char *filename);

int main(int argc, char *argv[])
{
    /* Head pointer for file linked list */
    Flist *head = NULL;

    /* Hash table */
    Hash_t hash[HASH_SIZE];

    int choice, i;
    int create_flag = 0;

    /* Initialize all hash table entries */
    for (i = 0; i < HASH_SIZE; i++)
    {
        hash[i].index = i;
        hash[i].link = NULL;
    }

    /* Validate command line arguments */
    if (validate_args(argc, argv, &head) == FAILURE)
    {
        printf("Validation Failed\n");
        return FAILURE;
    }

    printf("Validation Successful\n");

    /* Display menu until user exits */
    while (1)
    {
        printf("\n******** MENU ********\n");
        printf("1. Create Database\n");
        printf("2. Display Database\n");
        printf("3. Search Database\n");
        printf("4. Save Database\n");
        printf("5. Update Database\n");
        printf("6. Exit\n");
        printf("**********************\n");

        /* Read user choice */
        printf("Enter your choice : ");
        scanf("%d", &choice);

        /* Perform operation based on user choice */
        switch (choice)
        {
            /* Create the database */
            case 1:

                if (create_database(head, hash) == SUCCESS)
                {
                    printf("Database created successfully\n");

                    /* Set database created flag */
                    db_created = 1;
                }

                break;

            /* Display the database */
            case 2:

                /* Check whether database is created */
                if (db_created == 0)
                {
                    printf("Create the database first.\n");
                }
                else
                {
                    display_database(hash);
                }

                break;

            /* Search a word */
            case 3:
            {
                char word[WORD_SIZE];

                /* Read the word to search */
                printf("Enter word to search : ");
                scanf("%s", word);

                /* Search the word */
                search_database(hash, word);

                break;
            }

            /* Save database into backup file */
            case 4:
            {
                char save_file[FILE_SIZE];

                /* Read backup file name */
                printf("Enter backup file name : ");
                scanf("%s", save_file);

                /* Save database */
                save_database(hash, save_file);

                break;
            }

            /* Update database from backup file */
            case 5:
            {
                char backup_file[FILE_SIZE];

                /* Read backup file name */
                printf("Enter backup file name : ");
                scanf("%s", backup_file);

                /* Update database */
                update_database(hash, backup_file, head);

                break;
            }

            /* Exit the program */
            case 6:

                printf("Exiting...\n");
                return SUCCESS;

            /* Invalid choice */
            default:

                printf("Invalid Choice.\n");
        }
    }

    return SUCCESS;
}